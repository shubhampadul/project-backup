package com.clover.test.repo;

import com.clover.test.entity.Student;

import io.quarkus.hibernate.orm.panache.PanacheRepository;

public interface StudentRepo extends PanacheRepository<Student> {

}
