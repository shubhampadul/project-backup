package com.clover.test.resource;

import java.util.List;

import com.clover.test.entity.Student;
import com.clover.test.repo.StudentRepo;

import jakarta.inject.Inject;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/test")
public class StudentResource {
	
	@Inject
	private StudentRepo studentRepo;
	
	@GET
	@Path("/getStudentList")
	@Produces(MediaType.APPLICATION_JSON)
	public Response fetchStudentList() {
		
		List<Student> studentList = studentRepo.listAll();
	
	  return Response.ok(studentList).build();
			
	}

}
