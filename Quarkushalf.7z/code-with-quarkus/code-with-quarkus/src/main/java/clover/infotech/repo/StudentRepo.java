package clover.infotech.repo;

import clover.infotech.entity.Student;
import io.quarkus.hibernate.orm.panache.PanacheRepository;

public class StudentRepo implements PanacheRepository<Student>{

}
