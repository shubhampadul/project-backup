package org.acme.response;

import java.net.URI;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import jakarta.transaction.Transactional;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/laptop")
public class LaptopResource {

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAllLaptop() {
		List<Laptop> laptopList = Laptop.listAll();
		return Response.ok(laptopList).build();

	}

	@POST
	@Transactional
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response saveLaptop(Laptop laptop) {
		Laptop.persist(laptop);
		if (laptop.isPersistent()) {
			return Response.created(URI.create("/laptop/" + laptop.id)).build();
		} else {
			return Response.status(Response.Status.BAD_REQUEST).build();
		}
	}

	@GET
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getById(@PathParam("id") Long id) {
		Laptop laptop = Laptop.findById(id);
		return Response.ok(laptop).build();

	}

	@PUT
	@Transactional
	@Path("/{id}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response updateLaptop(@PathParam("id") Long id, Laptop updateLaptop) {
		Optional<Laptop> optionalLaptop = Laptop.findByIdOptional(id);
		if (optionalLaptop.isPresent()) {
			Laptop dbLaptop = optionalLaptop.get();
			if (Objects.nonNull(updateLaptop.getName())) {
				dbLaptop.setName(updateLaptop.getName());
			}
			if (Objects.nonNull(updateLaptop.getBrand())) {
				dbLaptop.setBrand(updateLaptop.getBrand());
			}
			if (Objects.nonNull(updateLaptop.getRam())) {
				dbLaptop.setRam(updateLaptop.getRam());
			}
			if (Objects.nonNull(updateLaptop.getExternalStorage())) {
				dbLaptop.setExternalStorage(updateLaptop.getExternalStorage());
			}
			dbLaptop.persist();
			if (dbLaptop.isPersistent()) {
				return Response.created(URI.create("/laptop/" + id)).build();

			}
		} else {
			return Response.status(Response.Status.BAD_REQUEST).build();

		}
		return null;
	}

	@DELETE
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response deleteLaptop(@PathParam("id") Long id) {
		boolean isDeleted = Laptop.deleteById(id);
		if (isDeleted) {
			return Response.noContent().build();
		} else {
			return Response.status(Response.Status.BAD_REQUEST).build();
		}

	}

}
