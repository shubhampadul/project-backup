package clover;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class infotechIT extends infotechTest {
    // Execute the same tests but in packaged mode.
}
